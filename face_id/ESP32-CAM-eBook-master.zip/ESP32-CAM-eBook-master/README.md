# Build ESP32-CAM Projects using Arduino IDE eBook

Build projects with the ESP32-CAM using Arduino IDE: photo capture, web servers, email notifications, video streaming, car robot, pan and tilt server, face detection, face recognition and much more.

https://randomnerdtutorials.com/esp32-cam-projects-ebook/
